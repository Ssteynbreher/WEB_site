from flask import Flask

app = Flask(__name__, static_folder='app/static', template_folder='app/templates')

from app import routes